// Update the clock every second
function updateClock() {
    const clock = document.getElementById("clock");
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, "0");
    const minutes = String(now.getMinutes()).padStart(2, "0");
    const seconds = String(now.getSeconds()).padStart(2, "0");
    clock.textContent = `${hours}:${minutes}:${seconds}`;
  }
  
  // Toggle theme and store it in localStorage
  function toggleTheme() {
    document.body.classList.toggle("dark-theme");
    const isDark = document.body.classList.contains("dark-theme");
    localStorage.setItem("theme", isDark ? "dark" : "light");
  }
  
  // Apply stored theme on load
  function applyStoredTheme() {
    const storedTheme = localStorage.getItem("theme");
    if (storedTheme === "dark") {
      document.body.classList.add("dark-theme");
    }
  }
  
  // Event listeners
  document.getElementById("toggle-theme").addEventListener("click", toggleTheme);
  
  // Initial setup
  applyStoredTheme();
  updateClock();
  setInterval(updateClock, 1000);
  